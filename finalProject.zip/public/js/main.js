const errorsOutput = document.querySelector('#errorsOutput')
const errorsCount = document.querySelector('#errorsCount')
const alertMessage = '<div class="alert alert-danger" role="alert">Not valid input</div>'
var team1Count = 0;
var team2Count = 0;
var team3Count = 0;
const warningMessage = '<div class="alert alert-warning" role="alert">no Issues Found</div>';

const textAreaContent = '<html lang="en">\n<head>\n<title>Page Title</title>\n</head>\n<body>\n<div id="mathcontent"><math xmlns="http://www.w3.org/1998/Math/MathML">\n<mi>x</mi>\n<mo>=</mo>\n<mi>y</mi>\n</math>\n</div>\n<h1>This is a Heading</h1>\n<p style="background:#224367">This is a paragraph.</p>\n<img src="https://clipart-library.com/images/8i68RxG4T.png" width="100" height="100"></img>\n</body>\n</html>';
const blankUrl = '<div class="alert alert-danger" role="alert">Please add html code to check against WCAG guidelines</div>'

const testAccessibility = async (e) => {
    e.preventDefault()
    errorsOutput.innerHTML = ''
    errorsCount.innerHTML = ''
    resetTeamAssignment();
    const htmlcode = document.getElementById('mytextarea').value;
    if (htmlcode === '') {
        errorsOutput.innerHTML = blankUrl
    } else {
        loadState()
        const settings = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/xml',
            },
            body: htmlcode
        }
        const response = await fetch("/api/test", settings);

        if (response.status !== 200) {
            loadState(false)
            errorsOutput.innerHTML = alertMessage
        } else {
            const {
                issues
            } = await response.json()

            if ($(htmlcode).find("math").length) {
                if ($(htmlcode).find("mtext").length <= 0) {
                    let matherror = {
                        code: "MATHml error",
                        context: "<math>",
                        message: "missing mtext for math",
                        runner: "htmlcs"
                    };
                    issues.push(matherror);
                    console.log("missing mtext");
                }
            }
            addWcagErrorsToDom(issues)
            loadState(false)
            document.getElementById("resetResults").classList.remove("hideButton")
        }
    }
}

function resetTeamAssignment() {
    team1Count = 0;
    team2Count = 0;
    team3Count = 0;
    x = document.getElementById("teamone");
    x.innerHTML = "Team 1 = " + team1Count;
    x = document.getElementById("teamtwo");
    x.innerHTML = "Team 2 = " + team2Count;
    x = document.getElementById("teamthree");
    x.innerHTML = "Team 3 = " + team3Count;
}

function sendToSpecialist(code, c, team) {
    var x = document.getElementById(code);

    if (x.innerHTML === "unassign to Team " + team) {
        x.innerHTML = "assign to Team " + team;
        if (team == 1) {
            x = document.getElementById("teamone");
            x.innerHTML = "Team 1 = " + --team1Count;
        }
        if (team == 2) {
            x = document.getElementById("teamtwo");
            x.innerHTML = "Team 2 = " + --team2Count;
        }
        if (team == 3) {
            x = document.getElementById("teamthree");
            x.innerHTML = "Team 3 = " + --team3Count;
        }
    } else {
        x.innerHTML = "unassign to Team " + team;
        if (team == 1) {
            x = document.getElementById("teamone");
            x.innerHTML = "Team 1 = " + ++team1Count;
        }
        if (team == 2) {
            x = document.getElementById("teamtwo");
            x.innerHTML = "Team 2 = " + ++team2Count;
        }
        if (team == 3) {
            x = document.getElementById("teamthree");
            x.innerHTML = "Team 3 = " + ++team3Count;
        }
    }
}
window.onbeforeunload = function(e) {
    reload();
}

function reload() {
    var x = document.getElementById("iframe");
    var x = document.getElementById("mytextarea").value;
    document.getElementById('iframe').src = "data:text/html;charset=utf-8," + escape(x);
}
const addWcagErrorsToDom = (issues) => {

    errorsOutput.innerHTML = ''
    errorsCount.innerHTML = ''

    if (issues.length === 0) {
        errorsOutput.innerHTML = warningMessage
    } else {
        errorsCount.innerHTML = `
      <p class="alert alert-warning">${issues.length} issues found !</p>
    `
        var count = 0
        var countId = 0
        issues.forEach((issue) => {
            count = count + 1;
            countId = countId + 1;

            var team = 1;
            var message = issue.message;
            if (message.toLowerCase().match("Img element missing an alt attribute.")) {
                team = 1;
            }
            if (message.toLowerCase().match("contrast")) {
                team = 2;
            }
            if (message.toLowerCase().match("missing mtext for math")) {
                team = 3;
            }

            const output = `
        <div class="card mb-5">
          <div class="card-body">
            <h4>${issue.message}</h4>

            <p class="bg-light p-3 my-3">
              ${escapeHTML(issue.context)}
            </p>

            <p class="bg-secondary text-light p-2">
              CODE: ${issue.code}
							<button id="${countId}" class="btn btn-warning" onclick="sendToSpecialist(${countId},${count}, ${team})">assign to Team ${team}</button>
            </p>
						
          </div>
        </div>
      `
            if (count >= 2) {
                count = 0;
            }
            errorsOutput.innerHTML += output
        })
    }
    document.getElementById('iframe').src += '';
}

const loadState = (isLoading = true) => {
    const loader = document.querySelector('.loader')
    if (isLoading) {
        loader.style.display = 'block'
        errorsOutput.innerHTML = ''
    } else {
        loader.style.display = 'none'
    }
}

function escapeHTML(html) {
    return html
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;')
}

const resetResults = (e) => {
    e.preventDefault()
    errorsOutput.innerHTML = ''
    errorsCount.innerHTML = ''
    document.querySelector('#mytextarea').value = textAreaContent;
    resetTeamAssignment();
    reload();
}
document.querySelector('#form').addEventListener('submit', testAccessibility)
document.querySelector('#resetResults').addEventListener('click', resetResults)
