const puppeteer = require('puppeteer')
const express = require('express')
const pa11y = require('pa11y')
const xmlparser = require('express-xml-bodyparser');
const fs = require('fs');
const PORT = process.env.PORT || 5000

const app = express()
app.use(express.static('public'))
app.use(xmlparser());

app.post('/api/test', async (req, res) => {

    console.log(req.body)
    if (!req.body) {
        res.status(400).json({
            error: 'html source code is required'
        })
    } else {
        fs.writeFile('./public/file.html', req.rawBody, err => {
            if (err) {
                console.error("error occurred while writing to file.html");
                console.error(err);
            }
        });
        // make relative path
        const results = await pa11y('./public/file.html');
        console.log("LENGTH=" + results.issues.length);
        for (let i = 0; i < results.issues.length; i++) {
            if (results.issues[i].message.toLowerCase().match("the html element should have a lang")) {
                results.issues.splice(i, 1);
                console.log("popping 1");
            }
        }
        for (let i = 0; i < results.issues.length; i++) {
            if (results.issues[i].message.toLowerCase().match("a title should be provided for the document")) {
                results.issues.splice(i, 1);
                console.log("popping 2");
            }
        }
        console.log(results);
        res.status(200).json(results)
    }
})

app.get('/api/delfile', (req, res) => {
    startup();
    res.status(200).json("deleted file");
});

function startup() {
    // make relative path
    fs.copyFileSync('./public/file-back.html', './public/file.html');
}
startup();

app.listen(PORT, () => console.log(`Server started on port ${PORT}`))